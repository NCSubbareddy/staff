package com.gurukula;

public interface IBranchEntity {
	/**
	 * This method is used to click branch from entities link
	 */

	public void selectBranch();

	/**
	 * This method is used to create a new branch
	 * 
	 * @param branchName
	 *            - Name of the branch to be typed in the Name field
	 * @param branchCode
	 *            - Code of the branch to be typed in the Code field
	 */

	public void createNewBranch(String branchName, String branchCode);

	/**
	 * This method is used to edit the branch details
	 * 
	 * @param branchName
	 *            - Name of the branch to be edited
	 * @param newBranchName
	 *            - New name of the branch to be entered in the Name field
	 * @param branchCode
	 *            - New code of the branch to be typed in the Code field
	 */

	public void editBranch(String branchName, String newBranchName, String branchCode);

	/**
	 * This method is used to delete the branch
	 * 
	 * @param branchName
	 *            - Name of the branch to be deleted
	 */

	public void deleteBranch(String branchName);

	/**
	 * This method is used to search the branch with branch id or branch name
	 * 
	 * @param serachOption
	 *            - Provide "Id" if you want to search with Branch Id else
	 *            Provide "Name" to search with branch name
	 * @param serachValue
	 *            - If serachOtion is Id,provide branch id else provide the name
	 *            of the branch to search.
	 */
	public void queryBranch(String serachOption, String serachValue);

	/**
	 * This method is used to view the branch detail
	 * 
	 * @param branchName
	 *            - Provide the branch name to view its details
	 */

	public void viewBranchDetails(String branchName);

}
