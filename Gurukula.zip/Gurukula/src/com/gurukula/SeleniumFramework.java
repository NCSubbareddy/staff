package com.gurukula;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SeleniumFramework {
	public static WebDriver driver;

	private SeleniumFramework() {

	}

	public static String getProperty(String propertyname) {
		String propertyvalue = "";
		Properties prop = new Properties();
		try {
			File file = new File("GeneraralProperties.properties");
			FileInputStream fis = new FileInputStream(file);
			prop.load(fis);
			propertyvalue = prop.getProperty(propertyname);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propertyvalue;
	}

	public WebDriver getDriver() {
		String browser = getProperty("browsertype");
		if (browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "selenium jars\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		if (browser.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}
		if (browser.equalsIgnoreCase("internetexplorer")) {
			System.setProperty("webdriver.ie.driver", "selenium jars\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		return driver;
	}

	public Logger getLogger() {
		Logger logger = Logger.getLogger(SeleniumFramework.class);
		PropertyConfigurator.configure("D:\\SNTest\\Gurukula\\log4j.properties");
		return logger;
	}

	/*
	 * @Rule public static void takeScreenshot() {
	 * SeleniumFramework.getInstance().getLogger().debug(
	 * "Creating screenshot..."); Date date = new Date() ; SimpleDateFormat
	 * dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss") ; String
	 * scrFilename = dateFormat.format(date) + ".png" ; File scrFile =
	 * ((TakesScreenshot) driver).getScreenshotAs( OutputType.FILE); //String
	 * scrFilename = "Screenshot.png"; File outputFile = new
	 * File("D:\\SR_SN_Test\\TestResult", scrFilename);
	 * SeleniumFramework.getInstance().getLogger().info(scrFilename +
	 * " screenshot created."); try { FileUtils.copyFile(scrFile, outputFile); }
	 * catch (IOException ioe) {
	 * SeleniumFramework.getInstance().getLogger().error(
	 * "Error copying screenshot after exception.", ioe); } }
	 */
	public static SeleniumFramework getInstance() {
		return new SeleniumFramework();
	}

}
