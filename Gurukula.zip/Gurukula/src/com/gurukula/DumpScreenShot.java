package com.gurukula;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

/**
 * This class is intended to take screenshot and log the error message whenever
 * test case is failed
 * 
 * @author Subbareddy
 *
 */
public class DumpScreenShot extends TestWatcher {

	@Override
	public void failed(Throwable e, Description description) {
		SeleniumFramework.getInstance().getLogger().debug("Creating screenshot...");
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
		String scrFilename = dateFormat.format(date) + ".png";
		File scrFile = ((TakesScreenshot) Login.driver).getScreenshotAs(OutputType.FILE);
		File outputFile = new File("Screenshots", scrFilename);
		SeleniumFramework.getInstance().getLogger().info(scrFilename + " screenshot created.");
		SeleniumFramework.getInstance().getLogger().info(description);
		SeleniumFramework.getInstance().getLogger().info(e);
		try {
			FileUtils.copyFile(scrFile, outputFile);
		} catch (IOException ioe) {
			SeleniumFramework.getInstance().getLogger().error("Error copying screenshot after exception.", ioe);
		}
		//Login.driver.quit();
	}
}
