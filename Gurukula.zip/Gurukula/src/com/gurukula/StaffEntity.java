package com.gurukula;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.gurukula.elements.Entities_Staff;

/**
 * 
 * @author Subbareddy
 *
 */
public class StaffEntity extends Login implements IStaffEntity {
	/**
	 * This method is used to click the staff from Entities link
	 */
	public void selectStaffEntity() {
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Staff.lnkEntities));
		driver.findElement(Entities_Staff.lnkEntities).click();
		wait.until(ExpectedConditions.elementToBeClickable(Entities_Staff.lnkStaff));
		driver.findElement(Entities_Staff.lnkStaff).click();
	}

	/**
	 * This method is used to create a new staff
	 * 
	 * @param staffName
	 *            - Name of the staff to be typed in the Name field
	 * @param branchName
	 *            - Name of the branch to be selected from Branch dropdown
	 */

	public void createNewStaff(String staffName, String branchName) {
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Staff.staffTable));
		WebElement staffTable = driver.findElement(Entities_Staff.staffTable);
		wait.until(ExpectedConditions.elementToBeClickable(Entities_Staff.btnCreateNewStaff));
		driver.findElement(Entities_Staff.btnCreateNewStaff).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Staff.createOrEditForm));
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.txtStaffName));
		if (staffName.length() != 0 && staffName.matches("^[a-zA-Z][a-zA-Z\\s]*$")) {
			driver.findElement(Entities_Staff.txtStaffName).sendKeys(staffName);
			wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.drdBranch));
			Select drdbranch = new Select(driver.findElement(Entities_Staff.drdBranch));
			drdbranch.selectByVisibleText(branchName);
			driver.findElement(Entities_Staff.btnSave).click();
			wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Staff.createOrEditForm));
		} else {
			logger.error("Entered staffname is not in the correct format");

		}

	}

	/**
	 * This method is used to edit staff details
	 * 
	 * @param staffName
	 *            - Name of the staff to be edited
	 * @param newStaffName
	 *            - New name of the staff to be entered in the Staff field
	 * @param branchName
	 *            - New name of the branch to be selected from Branch dropdown
	 */

	public void editStaff(String staffName, String newStaffName, String branchName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.staffTable));
		WebElement table = driver.findElement(Entities_Staff.staffTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement elestaffName = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			System.out.println(elestaffName.getText());
			if (elestaffName.getText().equalsIgnoreCase(staffName)) {
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-primary btn-sm']"))
				.click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.createOrEditForm));
				String dialogconfirm = driver.findElement(Entities_Staff.createOrEditFormTitle).getText();
				System.out.println(dialogconfirm);
				Assert.assertEquals(dialogconfirm, "Create or edit a Staff");
				wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.txtStaffName));
				if (newStaffName.length() != 0 && newStaffName.matches("^[a-zA-Z][a-zA-Z\\s]*$")) {
					driver.findElement(Entities_Staff.txtStaffName).clear();
					driver.findElement(Entities_Staff.txtStaffName).sendKeys(newStaffName);
				}
				wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.drdBranch));
				if (branchName.equals("")) {
					Select drdbranch = new Select(driver.findElement(Entities_Staff.drdBranch));
					drdbranch.selectByVisibleText(branchName);
				}
				driver.findElement(Entities_Staff.btnSave).click();
				wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Staff.createOrEditForm));
				break;
			}

		}

	}

	/**
	 * This method is used to delete the staff
	 * 
	 * @param staffName
	 *            - Name of the staff to be deleted
	 */

	public void deleteStaff(String staffName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.staffTable));
		WebElement table = driver.findElement(Entities_Staff.staffTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement eleStaffName = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			System.out.println(eleStaffName.getText());
			if (eleStaffName.getText().equalsIgnoreCase(staffName)) {
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-danger btn-sm']"))
				.click();
				wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.deleteForm));
				String dialogconfirm = driver.findElement(Entities_Staff.deleteFormTitle).getText();
				System.out.println(dialogconfirm);
				Assert.assertEquals(dialogconfirm, "Confirm delete operation");
				driver.findElement(Entities_Staff.btnDeleteConfirm).click();
				wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Staff.deleteForm));
				break;
			}
		}

	}

	/**
	 * This method is used to search with either Staff Id or Staff Name
	 * 
	 * @param serachOption
	 *            - Provide "Id" if you want to search with Staff Id else
	 *            Provide "Name" to search with Staff name
	 * @param serachValue
	 *            - If serachOtion is Id,provide staff id else provide the name
	 *            of the staff to search.
	 */

	public void queryStaff(String serachOption, String serachValue) {


		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.txtSearchQuery));
		driver.findElement(Entities_Staff.txtSearchQuery).clear();
		driver.findElement(Entities_Staff.txtSearchQuery).sendKeys(serachValue);
		driver.findElement(Entities_Staff.btnSearchStaff).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.staffTable));
		WebElement stafftable = driver.findElement(Entities_Staff.staffTable);
		List<WebElement> rows = stafftable.findElements(By.tagName("tr"));
		logger.info(rows.size() - 1 + "branches are matching with the given search");
		if (serachOption.equalsIgnoreCase("Id")) {
			WebElement elestaffId = stafftable.findElement(By.xpath("//tr[1]/td[1]"));
			if (elestaffId.getText().contains(serachValue)) {
				SeleniumFramework.getInstance().getLogger().info(elestaffId.getText());

			}
		} else if (serachOption.equalsIgnoreCase("Name")) {
			for (int i = 1; i < rows.size(); i++) {
				WebElement elestaff = stafftable.findElement(By.xpath("//tr[" + i + "]/td[2]"));
				if (elestaff.getText().contains(serachValue)) {
					logger.info(elestaff.getText());

				}

			}
		}
	}


	/**
	 * This method is used to view the staff details
	 * 
	 * @param staffName
	 *            - Provide the staff name to view the details
	 */

	public void viewStaffDetails(String staffName) {


		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.staffTable));
		WebElement table = driver.findElement(Entities_Staff.staffTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement eleStaffName = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			if (eleStaffName.getText().equalsIgnoreCase(staffName)) {
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-info btn-sm']")).click();
				break;
			}
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.btnBack));
		String viewStaffName = driver.findElement(Entities_Staff.viewStaffName).getAttribute("value");
		String viewStaffBranch = driver.findElement(Entities_Staff.viewStaffCode).getAttribute("value");
		logger.info("Staff Name is ..." + viewStaffName);
		logger.info("Staff Branch Name is ..." + viewStaffBranch);
	}	

	/**
	 * This method is used to navigate to next/previous/first/last pages
	 * 
	 * @param pageOption - select page navigation option from the pageOption enum
	 */

	public void pagiation(PageOption pageoption) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.lstPager));
		switch (pageoption.toString()) {
		case "FirstPage": {
			driver.findElement(Entities_Staff.lnkFirst).click();
			break;
		}
		case "PreviousPage": {
			driver.findElement(Entities_Staff.lnkPrevious).click();
			break;
		}
		case "NextPage": {
			driver.findElement(Entities_Staff.lnkNext).click();
			break;
		}
		case "LastPage": {
			driver.findElement(Entities_Staff.lnkLast).click();
			break;
		}
		default:
			SeleniumFramework.getInstance().getLogger().error("page navigation options are not displayed");

		}

		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Staff.staffTable));

	}

}
