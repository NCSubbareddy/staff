package com.gurukula;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.gurukula.elements.Entities_Branch;

public class BranchEntity extends Login implements IBranchEntity {

	/**
	 * This method is used to click branch from entities link
	 */

	public void selectBranch() {
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Branch.lnkEntities));
		driver.findElement(Entities_Branch.lnkEntities).click();
		wait.until(ExpectedConditions.elementToBeClickable(Entities_Branch.lnkBranch));
		driver.findElement(Entities_Branch.lnkBranch).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.branchHomeTitle));
		String branchHomeTitle = driver.findElement(Entities_Branch.branchHomeTitle).getText();
		Assert.assertEquals("Branches", branchHomeTitle);
		logger.info("Entities Branch home page is displayed");
	}

	/**
	 * This method is used to create a new branch
	 * 
	 * @param branchName
	 *            - Name of the branch to be typed in the Name field
	 * @param branchCode
	 *            - Code of the branch to be typed in the Code field
	 */

	public void createNewBranch(String branchName, String branchCode) {
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Branch.branchTable));
		WebElement branchTable = driver.findElement(Entities_Branch.branchTable);
		wait.until(ExpectedConditions.elementToBeClickable(Entities_Branch.btnCreateNewBranch));
		driver.findElement(Entities_Branch.btnCreateNewBranch).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Branch.branchCreateOrEditForm));
		wait.until(ExpectedConditions.presenceOfElementLocated(Entities_Branch.createOrEditFormTitle));
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtBranchName));
		String createOrEditFormTitle = driver.findElement(Entities_Branch.createOrEditFormTitle).getText();
		Assert.assertEquals("Create or edit a Branch", createOrEditFormTitle);
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtBranchName));
		driver.findElement(Entities_Branch.txtBranchName).sendKeys(branchName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtBranchCode));
		driver.findElement(Entities_Branch.txtBranchCode).sendKeys(branchCode);
		driver.findElement(Entities_Branch.btnSave).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Branch.branchCreateOrEditForm));
		logger.info("New branch is created successfully");

	}

	/**
	 * This method is used to edit the branch details
	 * 
	 * @param branchName
	 *            - Name of the branch to be edited
	 * @param newBranchName
	 *            - New name of the branch to be entered in the Name field
	 * @param branchCode
	 *            - New code of the branch to be typed in the Code field
	 */

	@Override
	public void editBranch(String branchName, String newBranchName, String branchCode) {

		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.branchTable));
		WebElement table = driver.findElement(Entities_Branch.branchTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement branch = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			System.out.println(branch.getText());
			if (branch.getText().equalsIgnoreCase(branchName)) {
				System.out.println("tr[" + i + "]/button[@class='btn btn-primary btn-sm']");
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-primary btn-sm']"))
				.click();
				break;
			}

		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("editForm")));
		String dialogconfirm = driver.findElement(Entities_Branch.createOrEditFormTitle).getText();
		Assert.assertEquals(dialogconfirm, "Create or edit a Branch");
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtBranchName));
		driver.findElement(Entities_Branch.txtBranchName).clear();
		driver.findElement(Entities_Branch.txtBranchName).sendKeys(newBranchName);
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtBranchCode));
		driver.findElement(Entities_Branch.txtBranchCode).clear();
		driver.findElement(Entities_Branch.txtBranchCode).sendKeys(branchCode);
		driver.findElement(Entities_Branch.btnSave).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Branch.branchCreateOrEditForm));
		logger.info("New branch is created successfully");

	}

	/**
	 * This method is used to delete the branch
	 * 
	 * @param branchName
	 *            - Name of the branch to be deleted
	 */

	@Override
	public void deleteBranch(String branchName) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.branchTable));
		WebElement table = driver.findElement(Entities_Branch.branchTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement branch = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			if (branch.getText().equalsIgnoreCase(branchName)) {
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-danger btn-sm']"))
				.click();
				break;
			}

		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.deleteForm));
		String dialogconfirm = driver.findElement(Entities_Branch.deleteFormTitle).getText();
		Assert.assertEquals(dialogconfirm, "Confirm delete operation");
		driver.findElement(Entities_Branch.btnConfirmDelete).click();
		wait.until(ExpectedConditions.invisibilityOfElementLocated(Entities_Branch.deleteForm));
		logger.info("Branch is deleted successfully..");

	}

	/**
	 * This method is used to search the branch with branch id or branch name
	 * 
	 * @param serachOption
	 *            - Provide "Id" if you want to search with Branch Id else
	 *            Provide "Name" to search with branch name
	 * @param serachValue
	 *            - If serachOtion is Id,provide branch id else provide the name
	 *            of the branch to search.
	 */

	public void queryBranch(String serachOption, String serachValue) {

		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.txtserachQuery));
		driver.findElement(Entities_Branch.txtserachQuery).sendKeys(serachValue);
		driver.findElement(Entities_Branch.btnSearchBranch).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.branchTable));
		WebElement table = driver.findElement(Entities_Branch.branchTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		logger.info(rows.size() - 1 + "branches are matching with the given search");
		if (serachOption.equalsIgnoreCase("Id")) {
			WebElement elebranchId = table.findElement(By.xpath("//tr[1]/td[1]"));
			if (elebranchId.getText().contains(serachValue)) {
				logger.info(elebranchId.getText());

			}
		} else if (serachOption.equalsIgnoreCase("Name")) {

			for (int i = 1; i < rows.size(); i++) {
				WebElement branch = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
				if (branch.getText().contains(serachValue)) {
					logger.info(branch.getText());

				}
			}

		}
	}
	public void viewBranchDetails(String branchName) {

		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.branchTable));
		WebElement table = driver.findElement(Entities_Branch.branchTable);
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		for (int i = 1; i < rows.size(); i++) {
			WebElement branch = table.findElement(By.xpath("//tr[" + i + "]/td[2]"));
			if (branch.getText().equalsIgnoreCase(branchName)) {
				table.findElement(By.xpath("//tr[" + i + "]/descendant::button[@class='btn btn-info btn-sm']")).click();
				break;
			}
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(Entities_Branch.btnBack));
		String viewBranchName = driver.findElement(Entities_Branch.viewBranchName).getAttribute("value");
		String ViewBranchCode = driver.findElement(Entities_Branch.viewBranchCode).getAttribute("value");
		logger.info("Brnah name is ..." + viewBranchName);
		logger.info("Branch code is ..." + ViewBranchCode);

	}

}
