package com.gurukula.tests;

import org.junit.Rule;
import org.junit.Test;

import com.gurukula.DumpScreenShot;
import com.gurukula.Login;
import com.gurukula.ReadDataFromExcel;
import com.gurukula.Account;

public class AccountTests {
	@Rule
	public DumpScreenShot screenshot = new DumpScreenShot();

	/**
	 * Verify user is able to create a new account in Gurukula application 	
	 */
	@Test
	public void createNewAccount() {
		Login login = new Login();
		login.launchGurukula();
		Account user = new Account();
		String loginName = ReadDataFromExcel.getCellValue("AccountTestData", "createNewAccount", "LoginName");
		String emailId = ReadDataFromExcel.getCellValue("AccountTestData", "createNewAccount", "EmailId");
		String newPassword = ReadDataFromExcel.getCellValue("AccountTestData", "createNewAccount", "NewPassword");
		System.out.println(loginName + "..." + emailId + "..." + newPassword );
		user.createNewAccount(loginName, emailId, newPassword);
	}

	/**
	 * Verify that user is able to edit account details
	 */
	@Test
	public void editAccountDetails() {
		Login login = new Login();
		login.launchGurukula();
		login.login();
		Account user = new Account();
		String firstName = ReadDataFromExcel.getCellValue("AccountTestData", "editAccountDetails", "FirstName");
		String lastName = ReadDataFromExcel.getCellValue("AccountTestData", "editAccountDetails", "LastName");
		String emailId = ReadDataFromExcel.getCellValue("AccountTestData", "editAccountDetails", "EmailId");
		user.editAccountDetails(firstName,lastName,emailId);
		login.Logout();
	}

}
