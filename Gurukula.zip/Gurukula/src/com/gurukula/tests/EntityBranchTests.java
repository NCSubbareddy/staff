package com.gurukula.tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.gurukula.BranchEntity;
import com.gurukula.DumpScreenShot;
import com.gurukula.Login;
import com.gurukula.ReadDataFromExcel;

public class EntityBranchTests {
	@Rule
	public DumpScreenShot screenshot = new DumpScreenShot();
	
	@Before
	public void loginToGurukula() {
		Login login = new Login();
		login.launchGurukula();
		login.login();
	}

	/**
	 * Verify user is able to create new branches with valid details
	 */
	@Test
	public void createNewBranch() {
		BranchEntity branch = new BranchEntity();
		branch.selectBranch();
		String branchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "createNewBranch", "BranchName");
		String branchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "createNewBranch", "BranchCode");
		String[] branchNames = branchName.split(",");
		String[] branchCodes = branchCode.split(",");
		branch.createNewBranch(branchNames[0], branchCodes[0]);
		branch.createNewBranch(branchNames[1], branchCodes[1]);
		branch.createNewBranch(branchNames[2], branchCodes[2]);
	}

	/**
	 * Verify user is able to edit branch details
	 */
	@Test
	public void editBranchDetails() {
		BranchEntity branch = new BranchEntity();
		branch.selectBranch();
		String branchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "editBranchDetails", "BranchName");
		String branchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "editBranchDetails", "BranchCode");
		branch.createNewBranch(branchName, branchCode);
		String newBranchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "editBranchDetails", "NewBranchname");
		String newBranchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "editBranchDetails", "NewBranchCode");
		branch.editBranch(branchName, newBranchName, newBranchCode);
	}

	/**
	 * Verify user is able to delete the existing branch
	 */
	@Test
	public void deleteBranch() {
		BranchEntity branch = new BranchEntity();
		branch.selectBranch();
		String branchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "deleteBranch", "BranchName");
		String branchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "deleteBranch", "BranchCode");
		branch.createNewBranch(branchName, branchCode);
		branch.deleteBranch(branchName);
	}

	/**
	 * 7)	Verify user is able to query the branches with branch id or name
	 */
	@Test
	public void searchBranchQuery() {
		BranchEntity branch = new BranchEntity();
		branch.selectBranch();
		String branchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "searchBranchQuery", "BranchName");
		String branchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "searchBranchQuery", "BranchCode");
		String branchOption = ReadDataFromExcel.getCellValue("EntitiesTestData", "searchBranchQuery", "BranchSerachOption");
		branch.createNewBranch(branchName, branchCode);
		branch.queryBranch(branchOption, branchName);
	}
    /**
     * Verify user is able to view the branch details
     */
	@Test
	public void viewBranchDetails() {
		BranchEntity branch = new BranchEntity();
		branch.selectBranch();
		String branchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "viewBranchDetails", "BranchName");
		String branchCode = ReadDataFromExcel.getCellValue("EntitiesTestData", "viewBranchDetails", "BranchCode");
		branch.createNewBranch(branchName, branchCode);
		branch.viewBranchDetails(branchName);
	}
	
	@After
	public void logoutFromGurukula() {
		Login login = new Login();
		login.Logout();
	}
}
