package com.gurukula.tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

import com.gurukula.DumpScreenShot;
import com.gurukula.IStaffEntity.PageOption;
import com.gurukula.Login;
import com.gurukula.ReadDataFromExcel;
import com.gurukula.StaffEntity;

public class EntityStaffTests {
	@Rule
	public DumpScreenShot screenshot = new DumpScreenShot();

	@Before
	public void loginToGurukula() {
		Login login = new Login();
		login.launchGurukula();
		login.login();
	}
    /**
     * Verify user is able to create new staff with valid details
     */
	@Test
	public void createNewStaff() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		String[] staffNames = ReadDataFromExcel.getCellValue("EntitiesTestData", "createNewStaff", "StaffName").split(",");
		String[] staffBranches = ReadDataFromExcel.getCellValue("EntitiesTestData", "createNewStaff", "StaffBranch").split(",");
		s.createNewStaff(staffNames[0], staffBranches[0]);
		s.createNewStaff(staffNames[1], staffBranches[1]);
		s.createNewStaff(staffNames[2], staffBranches[2]);
		s.createNewStaff(staffNames[3], staffBranches[3]);

	}
	
	/**
	 * Verify user is able to edit staff details
	 */
	@Test
	public void editStaffDetails() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		String staffName = ReadDataFromExcel.getCellValue("EntitiesTestData", "editStaffDetails", "StaffName");
		String newStaffName = ReadDataFromExcel.getCellValue("EntitiesTestData", "editStaffDetails", "NewStaffName");
		String newBranchName = ReadDataFromExcel.getCellValue("EntitiesTestData", "editStaffDetails", "NewStaffBanch");
		s.editStaff(staffName, newStaffName, newBranchName);

	}

	/**
	 * Verify user is able to delete the existing staff
	 */
	@Test
	public void deleteStaff() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		String[] staffNames = ReadDataFromExcel.getCellValue("EntitiesTestData", "deleteStaff", "StaffName").split(",");
		s.deleteStaff(staffNames[0]);
		s.deleteStaff(staffNames[1]);
	}
    /**
     * Verify user is able to query the staff with staff Id or staff name
     */
	@Test
	public void searchStaffQuery() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		String searchOption = ReadDataFromExcel.getCellValue("EntitiesTestData", "searchStaffQuery", "StaffSerachOption");
		String serachValue = ReadDataFromExcel.getCellValue("EntitiesTestData", "searchStaffQuery", "StaffName");
		s.queryStaff(searchOption, serachValue);
	}
	
	/**
	 * Verify user is able to view the staff details
	 */

	@Test
	public void viewStaffDetails() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		String staffName = ReadDataFromExcel.getCellValue("EntitiesTestData","viewStaffDetails", "StaffName");
		String staffBranch = ReadDataFromExcel.getCellValue("EntitiesTestData", "viewStaffDetails", "StaffBranch");
		s.createNewStaff(staffName, staffBranch);
		s.viewStaffDetails(staffName);
	}

	/**
	 * Verify user is able to navigate to next page, last page, previous and first page in the staff page
	 */
	@Test
	public void pageNavigate() {
		StaffEntity s = new StaffEntity();
		s.selectStaffEntity();
		s.pagiation(PageOption.FIRSTPAGE);
		s.pagiation(PageOption.LASTPAGE);

	}

	@After
	public void logoutFromGurukula() {
		Login login = new Login();
		login.Logout();
	}

}
