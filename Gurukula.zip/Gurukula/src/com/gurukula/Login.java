package com.gurukula;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gurukula.elements.Home;

public class Login {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public Logger logger = SeleniumFramework.getInstance().getLogger();

	/**
	 * This method is used to launch the Gurukula application
	 */
	public void launchGurukula() {
		driver = SeleniumFramework.getInstance().getDriver();
		logger.info(SeleniumFramework.getProperty("browsertype") + "browser is launched");
		wait = new WebDriverWait(driver, 20);
		driver.manage().window().maximize();
		driver.get(SeleniumFramework.getProperty("applicationurl"));

	}

	/**
	 * This method is used to login to Gurukula application
	 */
	public void login() {
		wait.until(ExpectedConditions.elementToBeClickable(Home.lnkLogin));
		logger.info("Application is launched in " + SeleniumFramework.getProperty("browsertype") + "browser");
		String title = driver.findElement(Home.homePageTitle).getText();
		Assert.assertEquals("Welcome to Gurukula!", title);
		driver.findElement(Home.lnkLogin).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(Home.loginpageTitle));
		String loginTitle = driver.findElement(Home.loginpageTitle).getText();
		Assert.assertEquals("Authentication", loginTitle);
		wait.until(ExpectedConditions.presenceOfElementLocated(Home.txtLoginName));
		driver.findElement(Home.txtLoginName).sendKeys(SeleniumFramework.getProperty("username"));
		driver.findElement(Home.txtPassword).sendKeys(SeleniumFramework.getProperty("password"));
		driver.findElement(Home.chkAutomaticLogin).click();
		driver.findElement(Home.btnAuthenticate).click();

	}

	/**
	 * This method is used to logout from Gurukula application
	 */

	public void Logout() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(Home.lnkAccount));
		driver.findElement(Home.lnkAccount).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Home.lnkLogout));
		driver.findElement(Home.lnkLogout).click();
		logger.info("Gurukula application is logged out successfully");
		wait.until(ExpectedConditions.elementToBeClickable(Home.lnkLogin));
		driver.quit();
	}
}
