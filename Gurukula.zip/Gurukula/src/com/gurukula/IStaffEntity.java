package com.gurukula;

public interface IStaffEntity {
	/**
	 * This method is used to click the staff from Entities link
	 */

	public void selectStaffEntity();

	/**
	 * This method is used to create a new staff
	 * 
	 * @param staffName
	 *            - Name of the staff to be typed in the Name field
	 * @param branchName
	 *            - Name of the branch to be selected from Branch dropdown
	 */

	public void createNewStaff(String staffName, String branchName);

	/**
	 * This method is used to edit staff details
	 * 
	 * @param staffName
	 *            - Name of the staff to be edited
	 * @param newStaffName
	 *            - New name of the staff to be entered in the Staff field
	 * @param branchName
	 *            - New name of the branch to be selected from Branch dropdown
	 */

	public void editStaff(String staffName, String newStaffName, String branchName);

	/**
	 * This method is used to delete the staff
	 * 
	 * @param staffName
	 *            - Name of the staff to be deleted
	 */
	public void deleteStaff(String staffName);

	/**
	 * This method is used to search staff with either Staff Id or Staff Name
	 * 
	 * @param serachOption
	 *            - Provide "Id" if you want to search with Staff Id else
	 *            Provide "Name" to search with Staff name
	 * @param serachValue
	 *            - If serachOtion is Id,provide staff id else provide the name
	 *            of the staff to search.
	 */
	public void queryStaff(String serachOption, String serachValue);

	/**
	 * This method is used to view the staff details
	 * 
	 * @param staffName
	 *            - Provide the staff name to view the details
	 */

	public void viewStaffDetails(String staffName);

	/**
	 * This method is used to navigate to next/previous/first/last pages
	 * 
	 * @param pageOption - select page navigation option from the pageOption enum
	 */

	public void pagiation(PageOption pageOption);

	public enum PageOption {
		FIRSTPAGE("FirstPage"), PREVIOUSPAGE("PreviousPage"), NEXTPAGE("NextPage"), LASTPAGE("LastPage");

		private final String pageOption;

		private PageOption(String pageOption) {
			this.pageOption = pageOption;
		}

		@Override
		public String toString() {
			return pageOption.toString();
		}
	}

}
