package com.gurukula;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDataFromExcel 
{
	public static int getRowNumber(XSSFSheet testdataSheet, String testCaseName) {
		int rownumber;
		int noofrows = testdataSheet.getLastRowNum() - testdataSheet.getFirstRowNum();
		for (rownumber = 1; rownumber <= noofrows; rownumber++) {
			String actualTestCaseName = testdataSheet.getRow(rownumber).getCell(0).getStringCellValue();
			if (testCaseName.equals(actualTestCaseName)) {
				break;
			}
		}
		return rownumber;
	}

	public static int getColumnNumber(XSSFSheet testdataSheet, String columnName) {
		int columnNumber;
		int noofColumns = testdataSheet.getRow(0).getLastCellNum() - testdataSheet.getRow(0).getFirstCellNum();
		for (columnNumber = 0; columnNumber <= noofColumns; columnNumber++) {
			String actualColumnName = testdataSheet.getRow(0).getCell(columnNumber).getStringCellValue();
			if (columnName.equals(actualColumnName)) {
				break;
			}
		}
		return columnNumber;
	}

	public static String getCellValue(String sheetName, String testCaseName, String columnName) {
		String cellValue = "";
		try 
		{
			File file = new File("TestData\\GurukulaAutomationTestData.xlsx");
			FileInputStream fis = new FileInputStream(file);
			DataFormatter formater = new DataFormatter();
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet testdataSheet = wb.getSheet(sheetName);
			int rownum = getRowNumber(testdataSheet, testCaseName);
			int columnNumber = getColumnNumber(testdataSheet, columnName);
			XSSFCell cell = testdataSheet.getRow(rownum).getCell(columnNumber);
			if(cell.getCellType()==cell.CELL_TYPE_STRING)
			{
				cellValue = cell.getStringCellValue();
			}
			else if(cell.getCellType()==cell.CELL_TYPE_NUMERIC)
			{
				cellValue = formater.formatCellValue(cell);
			}
			else if(cell.getCellType() == cell.CELL_TYPE_BOOLEAN)
			{
				cellValue = formater.formatCellValue(cell);
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return cellValue;
	}

}
