package com.gurukula.elements;

import org.openqa.selenium.By;

/**
 * @author subbareddy
 * 
 *         This class is intended for maintaining all web elements
 *         identification details of entity staff.
 */
public class Entities_Staff {
	public static final By lnkEntities = By.xpath("//span[text()='Entities']");
	public static final By lnkStaff = By.xpath("//a[@ui-sref='staff']");
	public static final By staffTable = By.xpath("//table[@class='table table-striped']");
	public static final By btnCreateNewStaff = By.xpath("//button[@class='btn btn-primary']");

	public static final By createOrEditForm = By.name("editForm");
	public static final By createOrEditFormTitle = By.id("myStaffLabel");
	public static final By txtStaffName = By.name("name");
	public static final By drdBranch = By.name("related_branch");
	public static final By btnSave = By.xpath("//span[text()='Save']");
	public static final By btnCancel = By.xpath("//span[text()='Cancel']");

	public static final By deleteForm = By.name("deleteForm");
	public static final By btnDeleteConfirm = By.xpath("//span[text()='Delete']");
	public static final By deleteFormTitle = By.xpath("(//h4[@class='modal-title ng-scope'])[2]");

	public static final By txtSearchQuery = By.id("searchQuery");
	public static final By btnSearchStaff = By.xpath("//button[@class='btn btn-info']");

	public static final By lstPager = By.xpath("//ul[@class='pager']");
	public static final By lnkFirst = By.xpath("//a[text()='<<']");
	public static final By lnkPrevious = By.xpath("//a[text()='<']");
	public static final By lnkNext = By.xpath("//a[text()='>']");
	public static final By lnkLast = By.xpath("//a[text()='>>']");

	public static final By viewStaffName = By.xpath("(//input[@class='input-sm form-control'])[1]");
	public static final By viewStaffCode = By.xpath("(//input[@class='input-sm form-control'])[2]");
	public static final By btnBack = By.xpath("//span[text()='Back']");

}