package com.gurukula.elements;

import org.openqa.selenium.By;

/*
 * This class is intended to maintain all the webelement identification details present in the Gurukula Home page
 */
public class Home {
	// ************************* Login details ********************

	public static final By lnkLogin = By.linkText("login");
	public static final By homePageTitle = By.xpath("//h1[@translate='main.title']");
	public static final By loginpageTitle = By.xpath("//h1[@translate='login.title']");
	public static final By txtLoginName = By.id("username");
	public static final By txtPassword = By.id("password");
	public static final By chkAutomaticLogin = By.id("rememberMe");
	public static final By btnAuthenticate = By.xpath("//button[text()='Authenticate']");

	// ************************** Create New Account Details ******************

	public static final By lnkRegisterNewAccount = By.linkText("Register a new account");
	public static final By txtNewLoginName = By.name("login");
	public static final By txtEmailId = By.name("email");
	public static final By txtNewPassword = By.name("password");
	public static final By txtConfirmPassword = By.name("confirmPassword");
	public static final By btnRegister = By.xpath("//button[@class='btn btn-primary ng-scope']");
	public static final By msgRegistrationFailed = By.xpath("//div[@class='alert alert-danger ng-scope']");

	// ************************** Edit Account Details ******************

	public static final By lnkAccount = By.xpath("//span[text()='Account']");
	public static final By lnkAccountSettings = By.xpath("//span[text()='Settings']");

	public static final By txtUserFirstName = By.name("firstName");
	public static final By txtUserLastName = By.name("lastName");
	public static final By drdLanguage = By.name("langKey");
	public static final By btnSave = By.xpath("//button[@class='btn btn-primary ng-scope']");
	public static final By msgSettingsSaved = By.xpath("//div[@class='alert alert-danger ng-scope']");

	// **************************** logout details ****************************

	public static final By lnkLogout = By.xpath("//span[text()='Log out']");

}
