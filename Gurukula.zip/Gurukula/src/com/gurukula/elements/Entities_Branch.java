package com.gurukula.elements;

import org.openqa.selenium.By;

public class Entities_Branch {
	public static final By lnkEntities = By.xpath("//span[text()='Entities']");
	public static final By lnkBranch = By.xpath("//a[@ui-sref='branch']");
	public static final By branchHomeTitle = By.xpath("//h2[@translate='gurukulaApp.branch.home.title']");

	public static final By branchTable = By.xpath("//table[@class='table table-striped']");
	public static final By btnCreateNewBranch = By.xpath("//button[@class='btn btn-primary']");
	public static final By branchCreateOrEditForm = By.name("editForm");
	public static final By createOrEditFormTitle = By.xpath("//h4[@id='myBranchLabel']");
	public static final By txtBranchName = By.name("name");
	public static final By txtBranchCode = By.name("code");
	public static final By btnSave = By.xpath("//span[text()='Save']");

	public static final By deleteForm = By.name("deleteForm");
	public static final By deleteFormTitle = By.xpath("(//h4[@class='modal-title ng-scope'])[2]");
	public static final By btnConfirmDelete = By.xpath("//span[text()='Delete']");

	public static final By txtserachQuery = By.id("searchQuery");
	public static final By btnSearchBranch = By.xpath("//button[@class='btn btn-info']");

	public static final By viewBranchName = By.xpath("(//input[@class='input-sm form-control'])[1]");
	public static final By viewBranchCode = By.xpath("(//input[@class='input-sm form-control'])[2]");
	public static final By btnBack = By.xpath("//span[text()='Back']");

}
