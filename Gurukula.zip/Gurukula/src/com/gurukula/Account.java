package com.gurukula;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.gurukula.elements.Home;

public class Account extends Login implements IAccount {
	/**
	 * This method is used to create a new account
	 * 
	 * @param loginName
	 *            - the value to be typed in the login field
	 * @param emailId
	 *            - the value to be typed in the Email field
	 * @param password
	 *            - the user password to be typed in the Password and Confirm
	 *            Password fields
	 */

	public void createNewAccount(String loginName, String emailId, String password) {
		/*
		 * wait.until(ExpectedConditions.elementToBeClickable(Home.lnkAccount));
		 * driver.findElement(Home.lnkAccount).click();
		 */
		wait.until(ExpectedConditions.elementToBeClickable(Home.lnkRegisterNewAccount));
		driver.findElement(Home.lnkRegisterNewAccount).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Home.txtNewLoginName));
		driver.findElement(Home.txtNewLoginName).sendKeys(loginName);
		if (emailId.contains("@") && emailId.length() >= 5) {
			driver.findElement(Home.txtEmailId).sendKeys(emailId);
		}
		if (password.length() >= 5) {
			driver.findElement(Home.txtNewPassword).sendKeys(password);
			driver.findElement(Home.txtConfirmPassword).sendKeys(password);
		}
		driver.findElement(By.xpath("//button[@class='btn btn-primary ng-scope']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Home.msgRegistrationFailed));
		String errorMessage = driver.findElement(Home.msgRegistrationFailed).getText();
		logger.info(errorMessage);
		Assert.assertFalse(errorMessage, true);
	}

	/**
	 * This method is used to edit the account details like first name,last name
	 * etc.
	 * 
	 * @param firstName
	 *            - if you provide the data here,it will overwrite the existing
	 *            First Name Value with new value. else Provide "" if you do not
	 *            want to modify its value
	 * @param lastName
	 *            -if you provide the data here,it will overwrite the existing
	 *            Last Name Value with new value. else Provide "" if you do not
	 *            want to modify its value
	 * @param emailId
	 *            - if you provide the data here,it will overwrite the existing
	 *            E-mail Value with new value. else Provide "" if you do not
	 *            want to modify its value
	 */

	public void editAccountDetails(String firstName, String lastName, String emailId) {
		wait.until(ExpectedConditions.elementToBeClickable(Home.lnkAccount));
		driver.findElement(Home.lnkAccount).click();
		wait.until(ExpectedConditions.elementToBeClickable(Home.lnkAccountSettings));
		driver.findElement(Home.lnkAccountSettings).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(Home.txtUserFirstName));
		if (!firstName.equals("")) {
			driver.findElement(Home.txtUserFirstName).clear();
			driver.findElement(Home.txtUserFirstName).sendKeys(firstName);
		}
		if (!lastName.equals("")) {
			driver.findElement(Home.txtUserLastName).clear();
			driver.findElement(Home.txtUserLastName).sendKeys(lastName);
		}
		if (!emailId.equals("")) {
			driver.findElement(Home.txtEmailId).clear();
			driver.findElement(Home.txtEmailId).sendKeys(emailId);
		}
		wait.until(ExpectedConditions.presenceOfElementLocated(Home.btnSave));
		driver.findElement(Home.btnSave).click();
		wait.until(ExpectedConditions.presenceOfElementLocated(Home.msgSettingsSaved));
		String msgSettingsSaved = driver.findElement(Home.msgSettingsSaved).getText();
		Assert.assertEquals("An error has occurred! Settings could not be saved.", msgSettingsSaved);

	}

}
